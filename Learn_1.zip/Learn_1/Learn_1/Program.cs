﻿using System.ComponentModel.DataAnnotations;
using System.IO;

string line;
int m = 0;
int c = 0;


    StreamReader rd = new StreamReader("C:\\Users\\Andrey\\Desktop\\work\\task1.txt");
    line = rd.ReadLine();
    for (int i = 0; i < line.Length; i++)
    {
        if (line[i].ToString() != "A" && line[i].ToString() != "E") 
        {
            c++;
            if (c > m)
            {
                m = c;
            }
        }
        else
        {
            c = 1;
        }
    }
    Console.WriteLine(m);
